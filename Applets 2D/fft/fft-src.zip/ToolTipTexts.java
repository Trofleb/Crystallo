/* EscherFFT - ToolTipTexts.java
 * 
 * Author   : Nicolas Schoeni
 * Creation : 21 juin 2006
 * 
 * nicolas.schoeni@epfl.ch
 */

public abstract class ToolTipTexts {
	final static String emptyOpTable = "Please drag an item from 'Available inputs' and drop it here.\nYou may drop one or more item to do complex calculation with them.";
	final static String opHeaderTable = "Add, substract or multiply this operand.";
	final static String filterHeaderTable = "You may select wich part of the source image will be used.";
	final static String moveUpHeaderTable = "Move this operand one line up.";
	final static String moveDownHeaderTable = "Move this operand one line down.";
	final static String outputOp = "Select or drop an item which will be used as output. The image is erased before operation are applied. Only images from the right pane can be used as output.";
}
