import java.awt.Color;
import java.awt.image.BufferedImage;

/* EscherFFT - ComplexImage.java
 * 
 * Author   : Nicolas Schoeni
 * Creation : 21 juin 2006
 * 
 * nicolas.schoeni@epfl.ch
 */

public class ComplexImage extends ComplexImageDoubleSize {
	public ComplexImage(int size, boolean inverse, ComplexImageSystem complexImageSystem) {
		this(size, inverse, complexImageSystem, OutputSystem.createImage(size, Color.white));
	}
	public ComplexImage(int size, boolean inverse, ComplexImageSystem complexImageSystem, BufferedImage image) {
		super(size, inverse, complexImageSystem, image);
	}
}
