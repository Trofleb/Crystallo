import java.awt.image.BufferedImage;

import javax.swing.JPanel;

/* EscherFFT - GenericCanvas.java
 * 
 * Author   : Nicolas Schoeni
 * Creation : 2 juin 2006
 * 
 * nicolas.schoeni@epfl.ch
 */

public abstract class GenericCanvas extends JPanel {
	public String name;

	public abstract void destroy();
	public abstract BufferedImage getImage();
}
