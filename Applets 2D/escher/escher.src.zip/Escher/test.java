import java.applet.*;
import java.awt.*;
import java.awt.image.*;
import java.net.URL;

public
class test extends Applet {
   public boolean standAlone = true;
   int xoff=0, yoff=0;
   int ang=45;
   
   public static void main(String[] args) {
     test t = new test();
     t.init();
     t.start();
     System.out.println("here");
   }
   
   public void paint(Graphics g) {
     MediaTracker tracker = new MediaTracker(this);
     Image pimg = null, p2img = null, p16img = null, p162img = null;
     try {
       pimg = getImage(new URL(getCodeBase(), "redcross.gif"));
       p2img = getImage(new URL(getCodeBase(), "bluecross.gif"));
       p16img = getImage(new URL(getCodeBase(), "redcross16.gif"));
       p162img = getImage(new URL(getCodeBase(), "bluecross16.gif"));
     } catch (java.net.MalformedURLException e) {
     }
    
     tracker.addImage(pimg,0);
     tracker.addImage(p16img,0);
     tracker.addImage(p2img,0);
     tracker.addImage(p162img,0);
     try {
       tracker.waitForAll();
     } catch (java.lang.InterruptedException e) {
       System.out.println("InterruptedException");
     }
     
     ImageFilter filter = new RotateFilter(ang);
     ImageProducer prod = new FilteredImageSource(pimg.getSource(),filter);
     Image i2 = createImage(prod);
     tracker.addImage(i2,0);

     prod = new FilteredImageSource(p16img.getSource(),filter);
     Image i3 = createImage(prod);
     tracker.addImage(i3,0);

     try {
       tracker.waitForAll();
     } catch (java.lang.InterruptedException e) {
       System.out.println("InterruptedException");
     }
     if (pimg == null) {
       System.out.println("pimage = null");
     } else 
       System.out.println("all is fine\n");

     System.out.println("width: " + pimg.getWidth(null) + " vs " + i2.getWidth(this));

     g.drawLine(0,0,400,400);
     g.drawImage(i2,100-i2.getWidth(null)/2,100-i2.getHeight(null)/2,null);
     g.drawImage(p2img,100+xoff-p2img.getWidth(null)/2,100+yoff-p2img.getHeight(null)/2,null);
     g.drawImage(i2,100-i2.getWidth(null)/2,10-i2.getHeight(null)/2,null);
     g.drawImage(p2img,10+xoff-p2img.getWidth(null)/2,100+yoff-p2img.getHeight(null)/2,null);

     g.drawImage(i3,50-i3.getWidth(null)/2,50-i3.getHeight(null)/2,null);
     g.drawImage(p162img,50+xoff-p162img.getWidth(null)/2,50+yoff-p162img.getHeight(null)/2,null);
     g.drawImage(i3,50-i3.getWidth(null)/2,10-i3.getHeight(null)/2,null);
     g.drawImage(p162img,10+xoff-p162img.getWidth(null)/2,50+yoff-p162img.getHeight(null)/2,null);
     g.drawString("ang: " + ang + "; " + xoff + "," + yoff, 100,50);
     
     int w = p2img.getWidth(null);
     int a2 = ang%90;
     g.drawImage(p2img,200-w/2,200-w/2,null);
     g.drawImage(i2,(int) Math.round(200+xoff-w*(Math.cos((double) a2*Math.PI/180.0) + Math.sin((double) a2*Math.PI/180.0))/2),(int) Math.round(200+yoff-w*(Math.cos((double) a2*Math.PI/180.0) + Math.sin((double) a2*Math.PI/180.0))/2),null);

   }
   public boolean mouseDown(Event evt, int x, int y) {
     xoff++;
     yoff++;
     repaint();
     return true;
   }
   public boolean keyDown(Event evt, int key) {
     switch (key) {
       case Event.UP:
         yoff--;
         break;
          
       case Event.DOWN:
         yoff++;
         break;
         
       case Event.LEFT:
         xoff--;
         break;
         
       case Event.RIGHT:
         xoff++;
         break;
         
       default:
         ang += 5;
         if (ang >=360)
           ang -= 360;
         xoff = 0;
         yoff = 0;
     }
     repaint();
     return true;
   }
   
}
