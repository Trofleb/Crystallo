
public class BadEntry extends Exception {

}
